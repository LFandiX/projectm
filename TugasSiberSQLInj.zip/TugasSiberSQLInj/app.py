import logging
import os
from flask import Flask, request, render_template_string

# --- BAGIAN INI YANG DIUBAH ---
# Pastikan folder C:\logs sudah ada manual
log_file_path = r'C:\logs\serangan.log'

# Konfigurasi Log agar menulis ke file yang dipantau Wazuh
logging.basicConfig(
    filename=log_file_path, 
    level=logging.INFO, 
    format='%(asctime)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
# -----------------------------

app = Flask(__name__)

# HTML Template (Sama seperti sebelumnya)
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Bank Login - Secure Portal</title>
    <style>
        body { font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; background-color: #f0f2f5; }
        .login-container { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        input { display: block; margin: 10px 0; padding: 10px; width: 100%; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background-color: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; }
        .error { color: red; margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Simulasi Login</h2>
        {% if error %}
            <div class="error">{{ error }}</div>
        {% endif %}
        <form method="post">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>
"""

@app.route('/', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        ip_address = request.remote_addr
        
        # User: admin, Pass: admin123
        if username == 'admin' and password == 'admin123':
            # LOG SUKSES
            log_msg = f"CustomApp: LOGIN_SUCCESS User '{username}' from IP {ip_address}"
            logging.info(log_msg)
            print(f"[+] {log_msg}")
            return "<h1>Login Berhasil! Log terkirim ke Wazuh.</h1>"
        else:
            # LOG GAGAL (Target Serangan)
            log_msg = f"CustomApp: LOGIN_FAILED User '{username}' from IP {ip_address}"
            logging.info(log_msg)
            print(f"[-] {log_msg}") 
            error = "Password Salah! (Cek Log Wazuh)"

    return render_template_string(HTML_TEMPLATE, error=error)

if __name__ == '__main__':
    print(f"[*] Aplikasi berjalan. Log akan ditulis ke: {log_file_path}")
    print("[*] Pastikan folder C:\\logs sudah dibuat!")
    app.run(host='0.0.0.0', port=5000)