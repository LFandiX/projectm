import math
import random
import cv2
from layout import main

graph_points = [(x,400) for x in range(330,970,10)]
t = 0
temp = 22.0
ie_modes = ["1:2","1:3","1:4"]
ie_idx = 0
cv2.namedWindow("Ventilator GUI V2")

while True:
    # if running:
        # update params dinamis
        Pin_val  = 20 + 5*math.sin(t/20)
        Pexp_val = 5 + 2*math.cos(t/25)
        RR_val   = 18 + random.randint(-2,2)
        Temp_val = temp + 0.01*math.sin(t/100)  # lambat berubah
        IE_val   = ie_modes[ie_idx//100 % len(ie_modes)]

        params = [
        ("Pin",  f"{Pin_val:.2f}"),
        ("Pexp", f"{Pexp_val:.2f}"),
        ("I:E",  IE_val),   
        ("RR",   f"{RR_val:.2f}"),
        ("Temp", f"{Temp_val:.2f}")
    ]

        values = [f"{Pin_val:.0f}", f"{Pexp_val:.0f}", IE_val, f"{RR_val}"]

        # Geser grafik
        graph_points = [(x-5, y) for (x,y) in graph_points if x-5 > 330]
        new_x = 970
        new_y = 300 + int(100*math.sin(t/15))  # gelombang sinus
        graph_points.append((new_x,new_y))
        t += 1

        img = main(params, values, graph_points)
        cv2.imshow("Ventilator GUI V2", img)

        if cv2.waitKey(50) & 0xFF == 27:  # ESC keluar
            break

cv2.destroyAllWindows()